# Chapter 1 - Understanding the ASP.NET Core React Template

To restore the code for this chapter open `WebApplication1.sln` in Visual Studio and press *F5* to run the app.
