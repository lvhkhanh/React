# Chapter 2 - Creating Decoupled React and ASP.NET Core Apps

To restore the frontend code for this chapter, open the `frontend` folder in Visual Studio Code and run `npm install` in the terminal. `npm start` will then run the app in dev mode.

To restore the backend code for this chapter, open `QandA.sln` in the `backend` folder in Visual Studio and press *F5* to run the app.
