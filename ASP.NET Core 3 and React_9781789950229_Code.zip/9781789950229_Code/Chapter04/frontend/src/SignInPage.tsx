import React from 'react';
import { Page } from './Page';

export const SignInPage = () => <Page title="Sign In" />;
