# Chapter 5 - Working with Forms

To restore the frontend code for this chapter, open the `frontend` folder in Visual Studio Code and run `npm install` in the terminal. `npm start` will then run the app in dev mode.