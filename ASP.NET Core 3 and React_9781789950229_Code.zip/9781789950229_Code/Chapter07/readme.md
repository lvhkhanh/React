# Chapter 7 - Interacting with the Database with Dapper

To restore the backend code for this chapter, open `QandA.sln` in the `backend` folder in Visual Studio. Press *F5* to run the app.

