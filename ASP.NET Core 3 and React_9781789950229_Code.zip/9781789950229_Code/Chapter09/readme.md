# Chapter 9 - Creating a Real-Time API with SignalR

To restore the frontend code for this chapter, open the `frontend` folder in Visual Studio Code and run `npm install` in the terminal. `npm start` will then run the app in dev mode.

To restore the backend code for this chapter, open `QandA.sln` in the `backend` folder in Visual Studio. Double check the connection string in `appsettings.json` points to your database and press *F5* to run the app.
