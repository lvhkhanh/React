# Chapter 10 - Improving Performance and Scalability

To restore the backend code for this chapter, open `QandA.sln` in the `backend` folder in Visual Studio. Double check the connection string in `appsettings.json` points to your database and press *F5* to run the app.