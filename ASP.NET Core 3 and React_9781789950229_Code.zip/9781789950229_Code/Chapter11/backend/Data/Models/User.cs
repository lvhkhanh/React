﻿namespace QandA.Data.Models
{
    public class User
    {
        public string Name { get; set; }
    }
}