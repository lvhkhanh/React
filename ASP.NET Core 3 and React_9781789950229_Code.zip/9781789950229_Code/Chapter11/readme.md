# Chapter 11 - Securing the Backend

To restore the backend code for this chapter, open `QandA.sln` in the `backend` folder in Visual Studio. Double check the connection string in `appsettings.json` points to your database and that the Auth0 settings are correct. Press *F5* to run the app.