using System;
using Xunit;

namespace BackendTests
{
    public static class Calc
    {
        public static decimal Add(decimal a, decimal b)
        {
            return a + b;
        }
    }
}
